﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ULMSWinFormsApp.Models;

namespace ULMSWinFormsApp.Forms
{
    public partial class FrmMarksCapture : Form
    {
        public FrmMarksCapture()
        {
            InitializeComponent();
        }
        private void btnCalculateResults_Click(object sender, EventArgs e)
        {
            try
            {
                MarkRecord record = new MarkRecord();

                record.StudentId = txtMarkStudentId.Text;
                record.StudentName = txtMarkStudentName.Text;

                record.Subject1 = Convert.ToDouble(txtSubject1.Text);
                record.Subject2 = Convert.ToDouble(txtSubject2.Text);
                record.Subject3 = Convert.ToDouble(txtSubject3.Text);

                // Validation
                if (record.Subject1 < 0 || record.Subject1 > 100 ||
                   record.Subject2 < 0 || record.Subject2 > 100 ||
                   record.Subject3 < 0 || record.Subject3 > 100)
                {
                    MessageBox.Show("Marks must be between 0 and 100");
                    return;
                }

                // Correct average calculation
                record.Average = (record.Subject1 + record.Subject2 + record.Subject3) / 3;

                if (record.Average >= 50)
                {
                    record.ResultStatus = "PASS";
                }
                else
                {
                    record.ResultStatus = "FAIL";
                }

                txtMarksOutput.Text =
                    "Marks processed successfully!" + Environment.NewLine +
                    "Student ID: " + record.StudentId + Environment.NewLine +
                    "Student Name: " + record.StudentName + Environment.NewLine +
                    "Subject 1: " + record.Subject1 + Environment.NewLine +
                    "Subject 2: " + record.Subject2 + Environment.NewLine +
                    "Subject 3: " + record.Subject3 + Environment.NewLine +
                    "Average: " + record.Average + Environment.NewLine +
                    "Final Result: " + record.ResultStatus;
            }
            catch
            {
                MessageBox.Show("Please enter valid numeric marks");
            }
        }

        private void btnClearMarks_Click(object sender, EventArgs e)
        {
            txtMarkStudentId.Clear();
            txtMarkStudentName.Clear();
            txtSubject1.Clear();
            txtSubject2.Clear();
            txtSubject3.Clear();
            txtMarksOutput.Clear();
            txtMarkStudentId.Focus();
        }

        private void btnBackMarks_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtSubject1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMarkStudentId_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
