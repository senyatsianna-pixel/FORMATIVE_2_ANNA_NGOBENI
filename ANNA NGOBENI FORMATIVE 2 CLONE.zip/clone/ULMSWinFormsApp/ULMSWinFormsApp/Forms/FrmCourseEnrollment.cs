﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ULMSWinFormsApp.Models;

namespace ULMSWinFormsApp.Forms
{
    public partial class FrmCourseEnrollment : Form
    {
        public FrmCourseEnrollment()
        {
            InitializeComponent();
        }

        private List<string> enrolledCourses = new List<string>();

        private void btnEnroll_Click(object sender, EventArgs e)
        {
            try
            {
                // Empty field validation
                if (string.IsNullOrEmpty(txtEnrollStudentId.Text) ||
                    string.IsNullOrEmpty(txtEnrollStudentId.Text) ||
                    string.IsNullOrEmpty(cmbCourse.Text) ||
                    string.IsNullOrEmpty(cmbSemester.Text))
                {
                    MessageBox.Show("Please complete all fields");
                    return;
                }

                // Student ID validation
                if (!int.TryParse(txtEnrollStudentId.Text, out int studentId))
                {
                    MessageBox.Show("Student ID must be numeric");
                    return;
                }

                // Duplicate enrollment validation
                string enrollmentKey =
                    txtEnrollStudentId.Text + "-" +
                    cmbCourse.Text + "-" +
                    cmbSemester.Text;

                if (enrolledCourses.Contains(enrollmentKey))
                {
                    MessageBox.Show("Student already enrolled in this course");
                    return;
                }

                enrolledCourses.Add(enrollmentKey);

                txtEnrollmentOutput.Text =
                    "Enrollment completed successfully!" + Environment.NewLine +
                    "Student ID: " + txtEnrollStudentId.Text + Environment.NewLine +
                    "Student Name: " + txtEnrollStudentId.Text + Environment.NewLine +
                    "Course: " + cmbCourse.Text + Environment.NewLine +
                    "Semester: " + cmbSemester.Text;

                MessageBox.Show("Enrollment successful");
            }
            catch
            {
                MessageBox.Show("Error during enrollment");
            }
        }

        private void btnClearEnrollment_Click(object sender, EventArgs e)
        {
            txtEnrollStudentId.Clear();
            txtEnrollStudentName.Clear();
            cmbCourse.SelectedIndex = -1;
            cmbSemester.SelectedIndex = -1;
            txtEnrollmentOutput.Clear();
            txtEnrollStudentId.Focus();
        }

        private void btnBackEnrollment_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmbCourse_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
