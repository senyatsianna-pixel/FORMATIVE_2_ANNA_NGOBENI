﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ULMSWinFormsApp.Models;

namespace ULMSWinFormsApp.Forms
{
    public partial class FrmStudentRegistration : Form
    {
        public FrmStudentRegistration()
        {
            InitializeComponent();
        }


        private List<string> registeredStudents = new List<string>();

        private void btnSaveStudent_Click(object sender, EventArgs e)
        {
            try
            {
                // Empty field validation
                if (string.IsNullOrEmpty(txtStudentId.Text) ||
                    string.IsNullOrEmpty(txtFullName.Text) ||
                    string.IsNullOrEmpty(txtEmail.Text) ||
                    string.IsNullOrEmpty(txtAge.Text) ||
                    string.IsNullOrEmpty(cmbProgramme.Text))
                {
                    MessageBox.Show("Please complete all fields");
                    return;
                }

                // Duplicate student validation
                if (registeredStudents.Contains(txtStudentId.Text))
                {
                    MessageBox.Show("Student ID already exists");
                    return;
                }

                // Email validation
                if (!txtEmail.Text.Contains("@"))
                {
                    MessageBox.Show("Invalid email format");
                    return;
                }

                // Age validation
                if (!int.TryParse(txtAge.Text, out int age))
                {
                    MessageBox.Show("Age must be numeric");
                    return;
                }

                if (age < 16 || age > 100)
                {
                    MessageBox.Show("Age must be between 16 and 100");
                    return;
                }

                // Save student
                Student student = new Student
                {
                    StudentId = txtStudentId.Text.Trim(),
                    FullName = txtFullName.Text.Trim(),
                    Email = txtEmail.Text.Trim(),
                    Age = age,
                    Programme = cmbProgramme.Text
                };

                registeredStudents.Add(student.StudentId);

                txtStudentOutput.Text =
                    "Student saved successfully!" + Environment.NewLine +
                    "Student ID: " + student.StudentId + Environment.NewLine +
                    "Full Name: " + student.FullName + Environment.NewLine +
                    "Email: " + student.Email + Environment.NewLine +
                    "Age: " + student.Age + Environment.NewLine +
                    "Programme: " + student.Programme;

                MessageBox.Show("Student registered successfully");
            }
            catch
            {
                MessageBox.Show("Error saving student");
            }
        }

        private void btnClearStudent_Click(object sender, EventArgs e)
        {
            txtStudentId.Clear();
            txtFullName.Clear();
            txtEmail.Clear();
            txtAge.Clear();
            cmbProgramme.SelectedIndex = -1;
            txtStudentOutput.Clear();
            txtStudentId.Focus();
        }

        //Add Back button to return to dashboard
        private void btnBackToDashboard_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
